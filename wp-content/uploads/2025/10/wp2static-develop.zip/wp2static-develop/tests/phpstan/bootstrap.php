<?php

// We use core constants instead of core functions
define( 'WPINC', '' );
define( 'WP_CONTENT_DIR', '' );
define( 'WP_PLUGIN_DIR', '' );

// WP2Static constants
define( 'WP2STATIC_VERSION', '' );
define( 'WP2STATIC_PATH', '' );
